package com.example.findnurse;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Looper;
import android.preference.PreferenceManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.iid.FirebaseInstanceId;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import static com.example.findnurse.Home.firebaseAuth;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {
    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COURSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;

    //user data
    private static String userID;
    private static String deviceTokenID;
    private static String email;
    private static String password;
    private static String name;
    private static String gender;
    private static String age;
    private static String mobileNumber;
    String longitude, latitude;

    //firestore
    FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    DocumentReference userDocRef;

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static boolean locationPermissionGranted = false;
    private GoogleMap mMap;
    private static Location currentLocation;
    // The entry point to the Fused Location Provider.
    private FusedLocationProviderClient mFusedLocationProviderClient;
    private LocationRequest locationRequest;
    private Location lastLocation;
    private LocationCallback locationCallback;


    //views
    private Button findNurseButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        email = PreferenceManager.getDefaultSharedPreferences(this).getString("email", "");
        password = PreferenceManager.getDefaultSharedPreferences(this).getString("password", "");
        name = PreferenceManager.getDefaultSharedPreferences(this).getString("name", "");
        gender = PreferenceManager.getDefaultSharedPreferences(this).getString("gender", "");
        age = PreferenceManager.getDefaultSharedPreferences(this).getString("age", "");
        if (email.equals("") || password.equals("") || name.equals("") || Objects.requireNonNull(age).equals("")
                || gender.equals("")) {
            startActivity(new Intent(this, WelcomeActivity.class));
            finish();
        }
        checkLanguage();
        setContentView(R.layout.activity_maps);
        Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.title);

        findNurseButton = findViewById(R.id.find_nurse);
        findNurseButton.setOnClickListener(v ->
                findNurseButton.setText("finding nearby nurses")
        );

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);

        getLocationPermission();
        createLocationRequest();
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                try {
                    for (Location location : locationResult.getLocations()) {
                        // Update UI with location data
                        // ...
                        lastLocation = location;
                        longitude = String.valueOf(lastLocation.getLongitude());
                        latitude = String.valueOf(lastLocation.getLatitude());
                        Map<String, Object> locationUpdates = new HashMap<>();
                        locationUpdates.put("longitude", longitude);
                        locationUpdates.put("latitude", latitude);
                        userDocRef.update(locationUpdates);
                        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
                        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                        mMap.animateCamera(CameraUpdateFactory.zoomTo(16f));
                    }
                } catch (NullPointerException ignored) {

                }
            }
        };
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseSignIn();

        mFusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback,
                Looper.getMainLooper());
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.clear();
//         Add a marker in Sydney and move the camera
//        LatLng sydney = new LatLng(-34, 151);
//        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
//        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        if (locationPermissionGranted && checkInternet())
            getDeviceLocation();
    }

    private boolean checkInternet() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        try {
            if (networkInfo != null && networkInfo.isConnected())
                return true;
            else
                Toast.makeText(this, R.string.check_connection, Toast.LENGTH_LONG).show();
        } catch (NullPointerException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            for (int index = permissions.length - 1; index >= 0; --index) {
                if (grantResults[index] != PackageManager.PERMISSION_GRANTED) {
                    // exit the app if one permission is not granted
                    Toast.makeText(this, "Required permission '" + permissions[index] + "' not granted, exiting",
                            Toast.LENGTH_LONG).show();
                    finish();
                    return;
                }
            }
            locationPermissionGranted = true;
            initMap();
        }
    }

    public void firebaseSignIn() {
        String email = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("email", "");
        String password = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("password", "");
        if (Objects.requireNonNull(email).equals("") || Objects.requireNonNull(password).equals("")) {
            startActivity(new Intent(MapsActivity.this, WelcomeActivity.class));
            finish();
        }
        else {
            firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    mobileNumber = Objects.requireNonNull(firebaseAuth.getCurrentUser()).getPhoneNumber();
                    userID = Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid();
                    deviceTokenID = FirebaseInstanceId.getInstance().getId();
                    Map<String, Object> userDataMap = new HashMap<>();
                    userDataMap.put("user_id", userID);
                    userDataMap.put("name", name);
                    userDataMap.put("email address", email);
                    userDataMap.put("mobile", mobileNumber);
                    userDataMap.put("age", age);
                    userDataMap.put("gender", gender);
                    userDataMap.put("device_token", deviceTokenID);
                    userDataMap.put("latitude", latitude);
                    userDataMap.put("longitude", longitude);
                    userDocRef = firebaseFirestore.collection("users_available").document(userID);
                    userDocRef.set(userDataMap).addOnFailureListener(e -> {
                        Log.e("firestore fail", e.toString());
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    });
                    Toast.makeText(MapsActivity.this, R.string.signed_in, Toast.LENGTH_LONG).show();
                }
            }).addOnFailureListener(e -> {
                Toast.makeText(MapsActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), WelcomeActivity.class));
                finish();
            });
        }
    }

    private void initMap() {
        SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        Objects.requireNonNull(supportMapFragment).getMapAsync(this);
    }

    private void getDeviceLocation() {
        try {
            if (locationPermissionGranted) {
                final Task location = mFusedLocationProviderClient.getLastLocation();
                location.addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        try {
                            currentLocation = (Location) task.getResult();
                            moveCamera(new LatLng(Objects.requireNonNull(currentLocation).getLatitude(),
                                    currentLocation.getLongitude()), 15f);
                            mMap.setMyLocationEnabled(true);
                            mMap.getUiSettings().setMapToolbarEnabled(true);

//                              addLocationAndTokenToFirestore(currentLocation);
                            //to add mark on current location
//                            mMap.addMarker(new MarkerOptions().position(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude())).title("Marker in Sydney"));
                        } catch (NullPointerException e) {
                            Toast.makeText(MapsActivity.this, R.string.enable_location,
                                    Toast.LENGTH_LONG).show();
                        }
                    } else
                        Toast.makeText(MapsActivity.this, "Unable to get current location", Toast.LENGTH_LONG).show();
                });
            }
        } catch (SecurityException ignored) {

        }
    }

    public void userSignOut(DocumentReference documentReference) {
        FirebaseAuth.getInstance().signOut();
        try {
            documentReference.delete().addOnSuccessListener(aVoid -> {

            }).addOnFailureListener(e -> Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show());
        } catch (Exception ignored) {
        }
    }

    protected void createLocationRequest() {
        locationRequest = LocationRequest.create();
        locationRequest.setInterval(1000);
        locationRequest.setFastestInterval(1000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

//    private void addLocationAndTokenToFirestore(Location currentLocation){
//        final Map <String, Object> map = new HashMap<>();
//        map.put("name", PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("firstName", "") +
//               " " + PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("secondName", ""));
//        map.put("gender", PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("gender", ""));
//        map.put("longitude", currentLocation.getLongitude());
//        map.put("latitude", currentLocation.getLatitude());
//        map.put("mobile", PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("mobileNumber", ""));
//        documentReference.set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
//            @Override
//            public void onSuccess(Void aVoid) {
//                documentReference.update("document ID", documentReference.getId());
//                documentReference.update("tokenID", FirebaseInstanceId.getInstance().getId());
//            }
//        });
//    }

    public void moveCamera(LatLng latLng, float zoom) {
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));
    }

    public void getLocationPermission() {
        String[] permissions = {FINE_LOCATION, COURSE_LOCATION};
        if (ContextCompat.checkSelfPermission(getApplicationContext(), FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
            if (ContextCompat.checkSelfPermission(getApplicationContext(), COURSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationPermissionGranted = true;
                initMap();
            } else
                ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);
        else
            ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);
    }

    public void language(String langCode) {
        Resources res = getResources();
        Locale locale = new Locale(langCode);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            config.setLayoutDirection(locale);
        }
        res.updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
    }

    public void checkLanguage() {
        String langCode = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("language", "ar");
        if (Objects.requireNonNull(langCode).equals("ar"))
            language("ar");
        else
            language("en");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.app_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent i;
        switch (item.getItemId()) {
            case R.id.reset_app:
                SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).edit();
                editor.remove("password");
                editor.remove("gender");
                editor.remove("mobileNumber");
                editor.remove("email");
                editor.remove("name");
                editor.remove("age");
                editor.commit();
                startActivity(new Intent(MapsActivity.this, WelcomeActivity.class));
                finish();
                break;
            case R.id.arabic:
                PreferenceManager.getDefaultSharedPreferences(getBaseContext()).edit().putString("language", "ar").commit();
                language("ar");
                i = getBaseContext().getPackageManager().getLaunchIntentForPackage(getBaseContext().getPackageName());
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
                finish();
                break;
            case R.id.english:
                PreferenceManager.getDefaultSharedPreferences(getBaseContext()).edit().putString("language", "en").commit();
                language("en");
                i = getBaseContext().getPackageManager().getLaunchIntentForPackage(getBaseContext().getPackageName());
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
        checkLanguage();
        if (email == "" || password == "" || name == "" || mobileNumber == ""
                || age == "" || gender == "") {
            startActivity(new Intent(MapsActivity.this, WelcomeActivity.class));
            finish();
        }
        else if (firebaseAuth == null) {
            firebaseAuth = FirebaseAuth.getInstance();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkLanguage();
        if (firebaseAuth == null) {
            firebaseSignIn();
            if (ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            mFusedLocationProviderClient.requestLocationUpdates(locationRequest,
                    locationCallback, Looper.getMainLooper());
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        userSignOut(userDocRef);
    }
}